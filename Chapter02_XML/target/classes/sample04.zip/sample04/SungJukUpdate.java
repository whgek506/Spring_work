package sample04;

public class SungJukUpdate implements SungJuk {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
