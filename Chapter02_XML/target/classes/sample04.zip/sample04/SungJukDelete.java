package sample04;

public class SungJukDelete implements SungJuk {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
