package sample04;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class SungJukInput implements SungJuk {

	@Override
	public void execute() {
		Scanner scan = new Scanner(System.in);
		System.out.println();
		
		System.out.print("이름을 입력하세요 : ");
	    String name = scan.next();
	    System.out.print("국어 점수를 입력하세요 : ");
	    int kor = scan.nextInt();
	    System.out.print("영어 점수를 입력하세요 : ");
	    int eng = scan.nextInt();
	    System.out.print("수학 점수를 입력하세요 : ");
	    int math = scan.nextInt();
	    
	    
	    
	}

}
