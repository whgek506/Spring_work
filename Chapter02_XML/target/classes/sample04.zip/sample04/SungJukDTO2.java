package sample04;

public class SungJukDTO2 {
	
}
